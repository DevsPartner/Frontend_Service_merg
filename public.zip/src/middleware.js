// src/middleware.js

import { NextResponse } from "next/server";

export function middleware(req) {
  // --- 1. ENV lesen ---
  const cookieName = process.env.JWT_COOKIE_NAME || "auth_token";

  // --- 2. Cookie holen ---
  const token = req.cookies.get(cookieName)?.value;

  // --- 3. Geschützte Routen definieren ---
  const protectedPaths = ["/products", "/checkout", "/profile"];

  const { pathname } = req.nextUrl;

  // --- 4. Prüfen, ob Route geschützt ist ---
  const isProtectedRoute = protectedPaths.some((p) =>
    pathname.startsWith(p)
  );

  // --- 5. Wenn geschützt + kein Token → redirect
  if (isProtectedRoute && !token) {
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
    loginUrl.search = ""; // Query löschen (optional)

    return NextResponse.redirect(loginUrl);
  }

  // --- 6. Wenn alles OK, Request normal weiterleiten ---
  return NextResponse.next();
}


// --- 7. Auf welche Routen Middleware angewendet wird ---
export const config = {
  matcher: [
    "/products/:path*",
    "/checkout/:path*",
    "/profile/:path*",
  ],
};
