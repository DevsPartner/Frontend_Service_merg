import { apiPost } from "@/lib/apiClient";

export default async function CheckoutPage() {
  const order = await apiPost("/orders/", {
    totalAmount: "19.98",
    items: [{ product_Id: 1, productName: "Sample", price: "19.98", quantity: 1 }],
  });
  return (
    <main className="p-6">
      <h1 className="text-xl font-semibold mb-2">Order erstellt</h1>
      <pre className="bg-gray-50 p-4 rounded">{JSON.stringify(order, null, 2)}</pre>
    </main>
  );
}
