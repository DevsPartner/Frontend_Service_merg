import { NextResponse } from "next/server";

export async function POST(request) {
  const { email, password } = await request.json();

  const backendUrl = `http://localhost:8000/auth/login`; // FIXED

  console.log("Backend URL:", backendUrl); // Debug

  const res = await fetch(backendUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return NextResponse.json({ error: err.detail || "Login failed" }, { status: res.status });
  }

  const backendSetCookie = res.headers.get("set-cookie");

  const response = NextResponse.json({ ok: true });
  if (backendSetCookie) {
    response.headers.set("set-cookie", backendSetCookie);
  }

  return response;
}
