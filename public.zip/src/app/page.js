export default function Home() {
  return (
    <main className="min-h-screen grid place-items-center">
      <a className="px-4 py-2 rounded bg-black text-white" href="/login">Go to Login</a>
    </main>
  );
}
