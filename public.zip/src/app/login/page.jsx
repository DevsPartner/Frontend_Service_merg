"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState(null);
  const router = useRouter();

  async function onSubmit(e) {
    e.preventDefault();
    setErr(null);

    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setErr(data.error || "Login fehlgeschlagen");
      return;
    }

    router.push("/products"); // protected page
  }

  return (
    <main className="min-h-screen grid place-items-center bg-gray-50">
      <form onSubmit={onSubmit} className="w-full max-w-sm space-y-4 p-6 bg-white rounded-2xl shadow">
        <h1 className="text-xl font-semibold">Login</h1>

        <input
          className="w-full border rounded px-3 py-2"
          placeholder="E-Mail"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          className="w-full border rounded px-3 py-2"
          placeholder="Passwort"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {err && <p className="text-sm text-red-600">{err}</p>}

        <button className="w-full bg-black text-white rounded px-4 py-2">
          Einloggen
        </button>
      </form>
    </main>
  );
}
