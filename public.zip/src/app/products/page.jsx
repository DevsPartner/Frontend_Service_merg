"use client";
import { useState, useEffect } from "react";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {

    async function fetchProducts() {
      try {
        const res = await fetch("http://localhost:8001/products");

        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);

        const data = await res.json();
        setProducts(data);

      } catch (err) {
        console.error("Failed to fetch products:", err);
        setError("Could not load products");
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, []);

  if (loading) return <p>Loading products...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <main className="p-6 grid gap-4 grid-cols-[repeat(auto-fill,minmax(220px,1fr))]">
      {products.map((p) => (
        <article key={p.id} className="rounded-2xl border p-4 bg-white shadow-sm">
          
          <div className="" />
           <img src={[p.imageLink]} alt="Product image" className="card-img-top aspect-4/3  rounded mb-3" />
          <h2 className="font-semibold">{p.name}</h2>
          <p className="text-sm text-gray-600 line-clamp-2">{p.description}</p>
          <div className="mt-2 font-medium">{p.price} €</div>
        </article>
      ))}
    </main>
  );
}
