/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx,mdx}",
    "./app/**/*.{js,jsx,ts,tsx,mdx}",   // falls du kein /src nutzt
  ],
  theme: { extend: {} },
  plugins: [],
};
